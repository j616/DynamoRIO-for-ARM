int dynamorio_syscall(unsigned int sysnum, unsigned int num_args, ...);
