void ATOMIC_DEC_int(int * someValue);
unsigned int SET_FLAG(unsigned int someFlag);
